
#include <iostream>
#include <cstring>
#include <string>
#include <iomanip>
#include <thread>
#include <chrono>
#include <fstream>  // For file handling

using namespace std;

// Struct to hold menu item details
struct MenuItem {
    string name;
    double price;
};

// Function declarations
void displayMenu();
void handleOrder(MenuItem items[], int numItems, string category, double& totalPrice, const string& username);
void calculateTotalPrice(MenuItem& item, int qty, double& total);
void managerMenu(MenuItem pizzas[], MenuItem burgers[], MenuItem sandwiches[], MenuItem drinks[], MenuItem fried[]);
void showLoadingScreen();
void applyDiscount(double& totalPrice);
bool validateInput(int& input, int min, int max);
bool validateQuantity(int& qty);
void saveOrderToFile(const string& username, const string& category, const string& itemName, int qty, double totalPrice);

int main()
{
    // Menu Items (Food and Drinks)
    MenuItem pizzas[] = { {"Chicken Fazita", 250.00}, {"Chicken Bar BQ", 500.00}, {"Peri Peri", 900.00}, {"Creamy Max", 450.00} };

    MenuItem burgers[] = { {"Zinger Burger", 180.00}, {"Chicken Burger", 150.00}, {"Beef Burger", 160.00} };

    MenuItem sandwiches[] = { {"Club Sandwich", 200.00}, {"Chicken Crispy Sandwich", 220.00}, {"Extreme Veg Sandwich", 180.00} };

    MenuItem drinks[] = { {"Mountain Dew", 50.00}, {"Coca Cola", 40.00}, {"Royal", 45.00} };

    MenuItem fried[] = { {"Chicken Fried", 250.00}, {"Prawn Fried", 300.00}, {"Beef Fried", 270.00} };

    int option = 0, qty, passwordAttempts = 3;
    double totalPrice = 0.0;
    char gotobeginning;
    char managerChoice;

    // Add login part
    char username[30], password[30];

    // Login System with Loading Screen
    showLoadingScreen();
    cout << "--------------------- Login ---------------------\n";
    while (passwordAttempts > 0)
    {
        cout << "Enter Username: ";
        cin >> username;
        cout << "Enter Password: ";
        cin >> password;

        if (strcmp(username, "admin") == 0 && strcmp(password, "password123") == 0)  // hardcoded username & password for simplicity
        {
            cout << "\nLogin successful! Welcome to Riphah Fast Food Ordering System.\n";
            break;
        }
        else
        {
            passwordAttempts--;
            cout << "\nIncorrect login details. You have " << passwordAttempts << " attempts left.\n";
            if (passwordAttempts == 0)
            {
                cout << "Too many failed attempts. Exiting program.\n";
                return 0;
            }
        }
    }

    // Option for manager login
    cout << "\nDo you want to login as a manager? (Y/N): ";
    cin >> managerChoice;

    // Validate the input for manager login (Y/N)
    while (managerChoice != 'Y' && managerChoice != 'y' && managerChoice != 'N' && managerChoice != 'n') {
        cout << "Invalid input. Please enter 'Y' for Yes or 'N' for No: ";
        cin >> managerChoice;
    }

    if (managerChoice == 'Y' || managerChoice == 'y') {
        // Manager login system
        char managerUsername[30], managerPassword[30];
        int managerAttempts = 3;

        cout << "--------------------- Manager Login ---------------------\n";
        while (managerAttempts > 0)
        {
            cout << "Enter Manager Username: ";
            cin >> managerUsername;
            cout << "Enter Manager Password: ";
            cin >> managerPassword;

            if (strcmp(managerUsername, "manager") == 0 && strcmp(managerPassword, "manager123") == 0) // hardcoded for simplicity
            {
                cout << "\nManager login successful! Welcome to the Menu Management System.\n";
                managerMenu(pizzas, burgers, sandwiches, drinks, fried);  // Call to the menu management system
                break;
            }
            else
            {
                managerAttempts--;
                cout << "\nIncorrect manager details. You have " << managerAttempts << " attempts left.\n";
                if (managerAttempts == 0)
                {
                    cout << "Too many failed attempts. Exiting program.\n";
                    return 0;
                }
            }
        }
    }

    // Main Menu and Ordering System
    do
    {
        system("cls"); // Clear the console
        cout << "\t\t\t|-------------------------------------------------------|\n";
        cout << "\t\t\t|              Riphah Fast Food Ordering System         |\n";
        cout << "\t\t\t|-------------------------------------------------------|\n\n";
        cout << "Hello " << username << "\n\nWhat would you like to order?\n\n";

        displayMenu();

        // Validate option input
        cout << "\nPlease Enter your Choice: ";
        while (!validateInput(option, 1, 5)) {
            cout << "Invalid choice. Please enter a valid option (1-5): ";
        }

        // Handle ordering for each category
        if (option == 1)
        {
            handleOrder(pizzas, 4, "Pizza", totalPrice, username); // Calls handleOrder for pizzas
        }
        else if (option == 2)
        {
            handleOrder(burgers, 3, "Burger", totalPrice, username);
        }
        else if (option == 3)
        {
            handleOrder(sandwiches, 3, "Sandwich", totalPrice, username);
        }
        else if (option == 4)
        {
            handleOrder(drinks, 3, "Drink", totalPrice, username);
        }
        else if (option == 5)
        {
            handleOrder(fried, 3, "Fried Food", totalPrice, username);
        }
        else
        {
            cout << "Invalid choice. Please try again.\n";
        }

        // Prompt to order more
        cout << "Would you like to order anything else? Y / N: ";
        cin >> gotobeginning;

    } while (gotobeginning == 'Y' || gotobeginning == 'y');

    // Show Order Summary
    cout << "\nYour total bill is: P" << fixed << setprecision(2) << totalPrice << "\n";

    // Apply Discount
    applyDiscount(totalPrice);
    cout << "Your final bill after discount is: P" << fixed << setprecision(2) << totalPrice << "\n";

    return 0;
}

// Function to display menu options
void displayMenu()
{
    cout << "\t\t\t|-------------------------------------------------------|\n";
    cout << "\t\t\t|                      Fast Food Menu                   |\n";
    cout << "\t\t\t|-------------------------------------------------------|\n\n";

    cout << "[Choice 1] Pizzas\n";
    cout << "[Choice 2] Burgers\n";
    cout << "[Choice 3] Sandwiches\n";
    cout << "[Choice 4] Drinks\n";
    cout << "[Choice 5] Fried Foods\n";
}

// Function to handle the order
void handleOrder(MenuItem items[], int numItems, string category, double& totalPrice, const string& username)
{
    int option, qty;
    double itemTotalPrice;
    cout << "\n--------- " << category << " Menu ---------\n";

    // Display menu items and prices
    for (int i = 0; i < numItems; i++)
    {
        cout << i + 1 << ") " << items[i].name << " P" << fixed << setprecision(2) << items[i].price << "\n";
    }

    // Validate item selection
    cout << "\nPlease enter your choice: ";
    while (!validateInput(option, 1, numItems)) {
        cout << "Invalid choice. Please enter a valid option (1-" << numItems << "): ";
    }

    if (option >= 1 && option <= numItems)
    {
        cout << "\nYou chose: " << items[option - 1].name << " for P" << fixed << setprecision(2) << items[option - 1].price << "\n";

        // Validate quantity
        cout << "Please Enter Quantity: ";
        while (!validateQuantity(qty)) {
            cout << "Invalid quantity. Please enter a positive number: ";
        }

        // Using pointer to pass item to calculate total price
        calculateTotalPrice(items[option - 1], qty, totalPrice);

        // Calculate the item total for display
        itemTotalPrice = items[option - 1].price * qty;
        cout << "\nYour total bill for " << items[option - 1].name << " is P" << fixed << setprecision(2) << itemTotalPrice;
        cout << "\nThank you for ordering from Riphah Fast Food\n";

        // Save the order to a file
        saveOrderToFile(username, category, items[option - 1].name, qty, itemTotalPrice);
    }
    else
    {
        cout << "Invalid selection.\n";
    }
}

// Function to calculate the total price using pointer and reference
void calculateTotalPrice(MenuItem& item, int qty, double& total)
{
    total += item.price * qty;
}

// Function to save the order to a file
void saveOrderToFile(const string& username, const string& category, const string& itemName, int qty, double totalPrice)
{
    ofstream file("order.txt", ios::in); // Open in append mode

    if (file.is_open())
    {
        file << "Username: " << username << "\n";
        file << "Category: " << category << "\n";
        file << "Item: " << itemName << "\n";
        file << "Quantity: " << qty << "\n";
        file << "Total Price: P" << fixed << setprecision(2) << totalPrice << "\n\n";

        file.close(); // Close the file after writing
    }
    else
    {
        cout << "Unable to open file to save the order.\n";
    }
}

// Function for manager to edit the menu
void managerMenu(MenuItem pizzas[], MenuItem burgers[], MenuItem sandwiches[], MenuItem drinks[], MenuItem fried[]) {
    int choice, itemChoice;
    string newName;
    double newPrice;
    char continueEditing;

    do {
        system("cls");
        cout << "\t\t\t|----------------------- Manager Menu ----------------------|\n";
        cout << "\t\t\t| 1) Edit Pizza Menu       | 2) Edit Burger Menu            |\n";
        cout << "\t\t\t| 3) Edit Sandwich Menu    | 4) Edit Drinks Menu            |\n";
        cout << "\t\t\t| 5) Edit Fried Food Menu  | 6) Exit                        |\n";
        cout << "\t\t\t|-----------------------------------------------------------|\n\n";
        cout << "Choose an option: ";
        while (!validateInput(choice, 1, 6)) {
            cout << "Invalid option. Please select between 1 and 6: ";
        }

        switch (choice) {
        case 1:
            cout << "Choose a Pizza to Edit:\n";
            for (int i = 0; i < 4; i++) {
                cout << i + 1 << ") " << pizzas[i].name << " - P" << pizzas[i].price << "\n";
            }

            cout << "Select a pizza to edit (1-4): ";
            while (!validateInput(itemChoice, 1, 4)) {
                cout << "Invalid choice. Please select between 1 and 4: ";
            }

            cout << "Enter new name for pizza: ";
            cin.ignore(); // To clear the newline character from input buffer
            getline(cin, newName);
            cout << "Enter new price for pizza: ";
            cin >> newPrice;

            pizzas[itemChoice - 1].name = newName;
            pizzas[itemChoice - 1].price = newPrice;
            cout << "Pizza updated successfully!\n";
            break;

        case 2:
            cout << "Choose a Burger to Edit:\n";
            for (int i = 0; i < 3; i++) {
                cout << i + 1 << ") " << burgers[i].name << " - P" << burgers[i].price << "\n";
            }
            cout << "Select a burger to edit (1-3): ";
            while (!validateInput(itemChoice, 1, 3)) {
                cout << "Invalid choice. Please select between 1 and 3: ";
            }

            cout << "Enter new name for burger: ";
            cin.ignore(); // To clear the newline character from input buffer
            getline(cin, newName);
            cout << "Enter new price for burger: ";
            cin >> newPrice;

            burgers[itemChoice - 1].name = newName;
            burgers[itemChoice - 1].price = newPrice;
            cout << "Burger updated successfully!\n";
            break;

        case 3:
            cout << "Choose a Sandwich to Edit:\n";
            for (int i = 0; i < 3; i++) {
                cout << i + 1 << ") " << sandwiches[i].name << " - P" << sandwiches[i].price << "\n";
            }
            cout << "Select a sandwich to edit (1-3): ";
            while (!validateInput(itemChoice, 1, 3)) {
                cout << "Invalid choice. Please select between 1 and 3: ";
            }

            cout << "Enter new name for sandwich: ";
            cin.ignore(); // To clear the newline character from input buffer
            getline(cin, newName);
            cout << "Enter new price for sandwich: ";
            cin >> newPrice;

            sandwiches[itemChoice - 1].name = newName;
            sandwiches[itemChoice - 1].price = newPrice;
            cout << "Sandwich updated successfully!\n";
            break;

        case 4:
            cout << "Choose a Drink to Edit:\n";
            for (int i = 0; i < 3; i++) {
                cout << i + 1 << ") " << drinks[i].name << " - P" << drinks[i].price << "\n";
            }
            cout << "Select a drink to edit (1-3): ";
            while (!validateInput(itemChoice, 1, 3)) {
                cout << "Invalid choice. Please select between 1 and 3: ";
            }

            cout << "Enter new name for drink: ";
            cin.ignore(); // To clear the newline character from input buffer
            getline(cin, newName);
            cout << "Enter new price for drink: ";
            cin >> newPrice;

            drinks[itemChoice - 1].name = newName;
            drinks[itemChoice - 1].price = newPrice;
            cout << "Drink updated successfully!\n";
            break;

        case 5:
            cout << "Choose a Fried Food to Edit:\n";
            for (int i = 0; i < 3; i++) {
                cout << i + 1 << ") " << fried[i].name << " - P" << fried[i].price << "\n";
            }
            cout << "Select a fried food to edit (1-3): ";
            while (!validateInput(itemChoice, 1, 3)) {
                cout << "Invalid choice. Please select between 1 and 3: ";
            }

            cout << "Enter new name for fried food: ";
            cin.ignore(); // To clear the newline character from input buffer
            getline(cin, newName);
            cout << "Enter new price for fried food: ";
            cin >> newPrice;

            fried[itemChoice - 1].name = newName;
            fried[itemChoice - 1].price = newPrice;
            cout << "Fried food updated successfully!\n";
            break;

        case 6:
            cout << "Exiting Manager Menu.\n";
            return; // Break out of the menu
            break;

        default:
            cout << "Invalid choice, please try again.\n";
        }

        // Ask if the user wants to continue editing the menu
        cout << "Do you want to edit another menu item? (Y/N): ";
        cin >> continueEditing;

        if (continueEditing == 'N' || continueEditing == 'n') {
            break; // Exit the loop if the user chooses to stop
        }

    } while (true); // Continue looping until the user chooses to exit
}


// Function to show a loading screen during login
void showLoadingScreen() {
    cout << "Loading Riphah Fast Food Ordering System... ";
    for (int i = 0; i < 5; i++)
    {
        this_thread::sleep_for(chrono::seconds(1));
        cout << ".";
    }
    cout << "\n\n";
}

// Function to apply discount if applicable
void applyDiscount(double& totalPrice) {
    char discountChoice;
    cout << "\nDo you have a discount coupon? (Y/N): ";
    cin >> discountChoice;
     
    while (discountChoice != 'Y' && discountChoice != 'y' && discountChoice != 'N' && discountChoice != 'n') {
        cout << "Invalid input. Please enter 'Y' for Yes or 'N' for No: ";
        cin >> discountChoice;
    }

    if (discountChoice == 'Y' || discountChoice == 'y')
    {
        double discount;
        cout << "Enter discount percentage: ";
        cin >> discount;
        totalPrice -= (totalPrice * discount / 100);
        cout << "Discount applied successfully!\n";
    }
}

// Function to validate input within a range (min-max)
bool validateInput(int& input, int min, int max) {
    cin >> input;
    if (cin.fail() || input < min || input > max) {   //cin.fail() checks if the input failed
        cin.clear(); // clear the error flag
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
        return false;
    }
    return true;
}

// Function to validate quantity (must be positive)
bool validateQuantity(int& qty) {
    cin >> qty;
    if (cin.fail() || qty <= 0) {   //cin.fail() checks if the input failed
        cin.clear(); // clear the error flag
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
        return false;
    }
    return true;
}
